import React, { useContext } from 'react'
import ProductContext from '../Context/ProductContext'

function CartItem({product}) {
    const {id, title,price,image}=product
    const {removeItem}= useContext (ProductContext)
    return (
        <div className='cart-item' >
            <img src={image} alt="" />

            <h3>{title}</h3>
           
                <h3>Price : ${price}</h3>
                <button className='remove' onClick={()=> removeItem(product.id)}>Remove Item</button>
           
        </div>
    )
}

export default CartItem