import React, { useContext } from 'react'
import View from '../component/View'
import ProductContext from '../Context/ProductContext'

function ViewItem() {
    const {cart}= useContext(ProductContext)
    const cartValue = cart.reduce((p,c)=>{
           return p+c.price
    },0)
  return (
    <>
    <div className="nav-cart">
     <div className="items">
     {
        cart.map((item)=>
        <View key ={item.id} item={item} />
        )
      } 
     </div>
     <div className="bill">
      <h1>Total Item : {cart.length}</h1>
      <h1>Total Amount : ${cartValue.toFixed(0)}</h1>
      <button className='buy'>Buy Now</button>
     
     </div>
   </div>
  
    </>
  )
}

export default ViewItem