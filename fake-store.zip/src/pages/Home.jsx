import React from 'react'
import ProductContainer from '../component/ProductContainer'

function Home() {
  return (
  <>
   <div className='img-section'></div>
   <ProductContainer/>
  </>
  )
}

export default Home